<?php header("Location: login.php"); exit(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Way to Home</title>
    <link rel="stylesheet" href="admin-login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="background-blobs">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
    </div>

    <div class="login-container">
        <div class="header">
            <div class="icon-box">
                <i class="fas fa-shield-halved"></i>
            </div>
            <h1>Admin Control</h1>
            <p class="subtitle">Secure access to management panel</p>
        </div>

        <form id="admin-login-form">
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" placeholder="admin" required autocomplete="username">
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" placeholder="••••••••" required
                        autocomplete="current-password">
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('password')"></i>
                </div>
            </div>

            <button type="submit" class="login-btn">
                <span>Sign In</span>
                <i class="fas fa-arrow-right"></i>
            </button>

            <div id="status-msg" class="status-msg"></div>
        </form>

        <a href="Dxy with Bheem.php" class="back-link">
            <i class="fas fa-chevron-left"></i> Back to Home
        </a>
    </div>

    <script>
        function togglePassword(id) {
            const el = document.getElementById(id);
            const icon = el.nextElementSibling;
            if (el.type === "password") {
                el.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                el.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>

</html>


