<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'add' || $action === 'edit') {
            $name = mysqli_real_escape_string($conn, $_POST['name']);
            $desc = mysqli_real_escape_string($conn, $_POST['description']);
            $cat = mysqli_real_escape_string($conn, $_POST['category']);
            $icon = mysqli_real_escape_string($conn, $_POST['icon']);
            $location_link = mysqli_real_escape_string($conn, $_POST['location_link']);
            
            if ($action === 'add') {
                $sql = "INSERT INTO `tourist_places` (name, description, category, icon, location_link) 
                        VALUES ('$name', '$desc', '$cat', '$icon', '$location_link')";
            } else {
                $id = (int)$_POST['id'];
                $sql = "UPDATE `tourist_places` SET name='$name', description='$desc', category='$cat', icon='$icon', 
                        location_link='$location_link' WHERE id=$id";
            }
            mysqli_query($conn, $sql);
        } elseif ($action === 'delete') {
            $id = (int)$_POST['id'];
            mysqli_query($conn, "DELETE FROM `tourist_places` WHERE id=$id");
        }
        header("Location: admin.php");
        exit();
    }
}


$placesResult = mysqli_query($conn, "SELECT * FROM `tourist_places` ORDER BY created_at DESC");
$usersResult = mysqli_query($conn, "SELECT id, fullname, username, email, created_at FROM `users` ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Dxy With Bheem</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="admin-container">
        <header class="admin-header">
            <div class="header-content">
                <h1><i class="fas fa-user-shield"></i> Admin Dashboard</h1>
                <div class="admin-nav">
                    <span style="font-weight: 500; font-size: 15px; margin-right: 15px;">Admin: <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                    <a href="home.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to App</a>
                    <a href="logout.php" class="back-link" style="background: rgba(239, 68, 68, 0.2); color: #ef4444;"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>

        <main class="admin-main">
            <div class="admin-grid">
                <!-- Attractions Management -->
                <section class="admin-card">
                    <div class="card-header">
                        <h2><i class="fas fa-map-marker-alt" style="color: #0072FF;"></i> Manage Tourist Places</h2>
                        <button id="add-place-btn" class="primary-btn" onclick="openModal('add')"><i class="fas fa-plus"></i> Add New Place</button>
                    </div>
                    <div id="places-list" class="admin-list">
                        <?php if ($placesResult && mysqli_num_rows($placesResult) > 0): ?>
                            <?php while ($place = mysqli_fetch_assoc($placesResult)): ?>
                                <div class="list-item">
                                    <div class="item-info">
                                        <h3><?php echo htmlspecialchars($place['name']); ?> <small><?php echo strtoupper($place['category']); ?></small></h3>
                                        <p><?php echo substr(htmlspecialchars($place['description']), 0, 100); ?>...</p>
                                    </div>
                                    <div class="item-actions">
                                        <button class="action-btn edit-btn" title="Edit" onclick='openModal("edit", <?php echo json_encode($place); ?>)'><i class="fas fa-edit"></i></button>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this place?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?php echo $place['id']; ?>">
                                            <button type="submit" class="action-btn delete-btn" title="Delete"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div style="text-align: center; padding: 40px; color: #94a3b8;">
                                <i class="fas fa-map-marked-alt" style="font-size: 40px; margin-bottom: 15px; display: block;"></i>
                                No tourist places found. Add your first one!
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <div style="display: flex; flex-direction: column; gap: 30px;">
                    <section class="admin-card">
                        <div class="card-header">
                            <h2><i class="fas fa-users" style="color: #0072FF;"></i> Registered Users</h2>
                        </div>
                        <div style="overflow-x: auto;">
                            <table>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>User Details</th>
                                        <th>Role</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($usersResult) while ($user = mysqli_fetch_assoc($usersResult)): ?>
                                        <tr>
                                            <td>#<?php echo $user['id']; ?></td>
                                            <td>
                                                <strong><?php echo htmlspecialchars($user['username']); ?></strong><br>
                                                <small style="color: #64748b;"><?php echo htmlspecialchars($user['email']); ?></small>
                                            </td>
                                            <td><span style="background: <?php echo $user['username'] === 'admin' ? '#fef3c7' : '#e0f2fe'; ?>; color: <?php echo $user['username'] === 'admin' ? '#92400e' : '#0369a1'; ?>; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase;">User</span></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </section>

                    <section class="admin-card" style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); color: white;">
                        <div class="card-header" style="border-bottom-color: rgba(255,255,255,0.1);">
                            <h2 style="color: white;"><i class="fas fa-external-link-alt" style="color: #00C6FF;"></i> Admin Insights</h2>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 10px;">
                            <a href="admin_history.php" style="text-decoration: none; padding: 15px; background: rgba(255,255,255,0.05); border-radius: 12px; color: white; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                                <i class="fas fa-history" style="font-size: 20px; margin-bottom: 10px; color: #00C6FF; display: block;"></i>
                                <div style="font-weight: 600; font-size: 14px;">User History</div>
                            </a>
                            <a href="view-feedback.php" style="text-decoration: none; padding: 15px; background: rgba(255,255,255,0.05); border-radius: 12px; color: white; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                                <i class="fas fa-comments" style="font-size: 20px; margin-bottom: 10px; color: #00C6FF; display: block;"></i>
                                <div style="font-weight: 600; font-size: 14px;">Feedbacks</div>
                            </a>
                            <a href="view_schedules.php" style="text-decoration: none; padding: 15px; background: rgba(255,255,255,0.05); border-radius: 12px; color: white; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'" onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                                <i class="fas fa-calendar-alt" style="font-size: 20px; margin-bottom: 10px; color: #00C6FF; display: block;"></i>
                                <div style="font-weight: 600; font-size: 14px;">Travel Schedules</div>
                            </a>
                        </div>
                    </section>
                </div>
            </div>
        </main>
    </div>


    <div id="place-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeModal()">&times;</span>
            <h2 id="modal-title" style="color: #1e293b; margin-bottom: 25px;">Add New Attraction</h2>
            <form id="place-form" method="POST">
                <input type="hidden" name="action" id="form-action" value="add">
                <input type="hidden" name="id" id="place-id">
                <div class="form-group">
                    <label>Attraction Name</label>
                    <input type="text" name="name" id="place-name" required placeholder="e.g. Panadura Beach">
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="place-desc" rows="3" required placeholder="Tell travelers why they should visit..."></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category" id="place-category">
                            <option value="beach">Beach</option>
                            <option value="heritage">Heritage</option>
                            <option value="temple">Temple</option>
                            <option value="nature">Nature</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Display Icon</label>
                        <select name="icon" id="place-icon"></select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Google Maps / Location Link</label>
                    <input type="url" name="location_link" id="place-link" placeholder="https://maps.google.com/..." required>
                </div>
                <div style="margin-top: 30px;">
                    <button type="submit" class="primary-btn" style="width: 100%; justify-content: center; padding: 15px;">Save Attraction</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const iconOptions = {
            beach: [
                { value: 'fa-umbrella-beach', label: 'Umbrella Beach' },
                { value: 'fa-water', label: 'Water' },
                { value: 'fa-sun', label: 'Sun' },
                { value: 'fa-swimmer', label: 'Swimmer' }
            ],
            heritage: [
                { value: 'fa-fort-awesome', label: 'Fort' },
                { value: 'fa-landmark', label: 'Landmark' },
                { value: 'fa-monument', label: 'Monument' },
                { value: 'fa-archway', label: 'Archway' }
            ],
            temple: [
                { value: 'fa-dharmachakra', label: 'Dharmachakra' },
                { value: 'fa-vihara', label: 'Vihara' },
                { value: 'fa-pray', label: 'Pray' },
                { value: 'fa-place-of-worship', label: 'Worship Place' }
            ],
            nature: [
                { value: 'fa-tree', label: 'Tree' },
                { value: 'fa-leaf', label: 'Leaf' },
                { value: 'fa-mountain', label: 'Mountain' }
            ]
        };

        function updateIconOptions() {
            const category = document.getElementById('place-category').value;
            const iconSelect = document.getElementById('place-icon');
            iconSelect.innerHTML = '';

            if (iconOptions[category]) {
                iconOptions[category].forEach(icon => {
                    const option = document.createElement('option');
                    option.value = icon.value;
                    option.textContent = icon.label;
                    iconSelect.appendChild(option);
                });
            }
        }

        document.getElementById('place-category').addEventListener('change', updateIconOptions);

        function openModal(mode, data = null) {
            document.getElementById('place-modal').style.display = 'block';
            if (mode === 'edit' && data) {
                document.getElementById('modal-title').innerText = 'Edit Attraction';
                document.getElementById('form-action').value = 'edit';
                document.getElementById('place-id').value = data.id;
                document.getElementById('place-name').value = data.name;
                document.getElementById('place-desc').value = data.description;
                document.getElementById('place-category').value = data.category;
                updateIconOptions();
                document.getElementById('place-icon').value = data.icon;
                document.getElementById('place-link').value = data.location_link || '';
            } else {
                document.getElementById('modal-title').innerText = 'Add New Attraction';
                document.getElementById('form-action').value = 'add';
                document.getElementById('place-form').reset();
                updateIconOptions();
            }
        }

        function closeModal() {
            document.getElementById('place-modal').style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == document.getElementById('place-modal')) {
                closeModal();
            }
        }
    </script>
</body>

</html>
