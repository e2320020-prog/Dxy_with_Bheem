/**
 * theme.js - Disabled
 * Theme switching functionality has been removed
 */
// All theme switching has been disabled

