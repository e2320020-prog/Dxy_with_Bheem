<?php
session_start();
require_once 'db_connect.php';
$statusMsg = "";
$statusClass = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    $sql_user = "SELECT * FROM `users` WHERE `username` = '$username'";
    $result_user = mysqli_query($conn, $sql_user);

    if (mysqli_num_rows($result_user) > 0) {
        $user = mysqli_fetch_assoc($result_user);
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['role'] = 'user';
            $statusMsg = "Login successful! Redirecting...";
            $statusClass = "status-success";
            header("refresh:1;url=home.php");
        } else {
            $statusMsg = "Invalid password.";
            $statusClass = "status-error";
        }
    } else {
        $sql_admin = "SELECT * FROM `admin` WHERE `username` = '$username'";
        $result_admin = mysqli_query($conn, $sql_admin);

        if (mysqli_num_rows($result_admin) > 0) {
            $admin = mysqli_fetch_assoc($result_admin);
            if (password_verify($password, $admin['password'])) {
                $_SESSION['user_id'] = $admin['id'];
                $_SESSION['username'] = $admin['username'];
                $_SESSION['fullname'] = 'Administrator';
                $_SESSION['role'] = 'admin';
                $statusMsg = "Admin Login successful! Redirecting...";
                $statusClass = "status-success";
                header("refresh:1;url=home.php");
            } else {
                $statusMsg = "Invalid admin password.";
                $statusClass = "status-error";
            }
        } else {
            $statusMsg = "User not found.";
            $statusClass = "status-error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dxy With Bheem</title>
    <link rel="stylesheet" href="auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="auth-container">
        <div class="brand-heading">Dxy With Bheem</div>
        <div class="auth-header">
            <i class="fas fa-route"></i>
            <h2>Welcome Back</h2>
            <p>Ready for your next journey?</p>
        </div>

        <form id="login-form" method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-wrapper">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="username" name="username" placeholder="Enter username" required value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" id="password" name="password" placeholder="Enter password" required>
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('password')"></i>
                </div>
            </div>

            <a href="forgot-password.php" class="forgot-link">Forgot Password?</a>

            <button type="submit" name="login" class="auth-btn">Log In</button>
            <?php if ($statusMsg): ?>
                <div id="status-msg" class="status-msg <?php echo $statusClass; ?>" style="display: block;"><?php echo $statusMsg; ?></div>
            <?php endif; ?>
        </form>

        <div class="auth-footer">
            Don't have an account? <a href="register.php">Sign Up</a>
        </div>
    </div>

    <script>
        function togglePassword(id) {
            const el = document.getElementById(id);
            const icon = el.nextElementSibling;
            if (el.type === "password") {
                el.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                el.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>

</html>
