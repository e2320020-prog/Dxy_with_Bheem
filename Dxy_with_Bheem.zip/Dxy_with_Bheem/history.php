<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$is_admin = ($role === 'admin');

if ($is_admin) {
    header("Location: admin_history.php");
    exit();
}

$sql = "SELECT id, user_id, user_type, location_name, search_type, created_at
        FROM `history`
        WHERE user_id = '$user_id' AND user_type = '$role'
        ORDER BY created_at DESC";

$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel History - Dxy With Bheem</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="history.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .history-item {
            display: flex;
            align-items: center;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 12px;
            border-left: 5px solid #00C6FF;
            transition: all 0.3s ease;
            margin-bottom: 15px;
        }
        .history-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            background: #f0f7ff;
        }
    </style>
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="history-container" style="padding: 40px 20px; display: flex; justify-content: center;">
            <div class="history-card" style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.1); width: 100%; max-width: 900px;">
                <div class="back-link" style="margin-bottom: 30px;">
                    <a href="home.php" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-weight: 600; font-family: 'Segoe UI', sans-serif;">
                        <i class="fas fa-arrow-left"></i> Back to Home
                    </a>
                </div>
                <div class="history-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <h2 style="margin: 0; font-size: 32px; color: #1e293b; font-family: 'Segoe UI', sans-serif;"><i class="fas fa-history" style="color: #0072FF;"></i> Travel History</h2>
                    <button id="clear-history-btn" class="clear-btn" onclick="clearHistory()" style="background: #ef4444; color: white; border: none; padding: 12px 24px; border-radius: 10px; cursor: pointer; font-weight: 600; transition: background 0.3s;">
                        <i class="fas fa-trash-alt"></i> Clear All
                    </button>
                </div>
                <p style="color: #64748b; margin-bottom: 40px; font-size: 16px;">Review your past explorations and destinations comfortably.</p>

                <div id="history-list" class="history-list">
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <div class="history-items-grid">
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <div class="history-item">
                                    <div class="history-icon" style="width: 55px; height: 55px; background: white; border-radius: 15px; display: flex; align-items: center; justify-content: center; margin-right: 25px; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
                                        <i class="fas fa-<?php echo ($row['search_type'] === 'tourist_place' || $row['search_type'] === 'selection' || $row['search_type'] === 'attraction') ? 'map-marker-alt' : 'search'; ?>" style="color: #0072FF; font-size: 22px;"></i>
                                    </div>
                                    <div class="history-info" style="flex: 1;">
                                        <div style="font-weight: 700; font-size: 19px; color: #1e293b; margin-bottom: 4px;"><?php echo htmlspecialchars($row['location_name']); ?></div>
                                        <div style="color: #94a3b8; font-size: 14px; display: flex; align-items: center; gap: 15px;">
                                            <span><i class="fas fa-calendar-alt"></i> <?php echo date('M j, Y, g:i a', strtotime($row['created_at'])); ?></span>
                                            <span style="color: #0ea5e9; font-weight: 600;"><i class="fas fa-tag"></i> <?php echo ucfirst(str_replace('_', ' ', $row['search_type'])); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="empty-msg" style="text-align: center; padding: 60px 20px; color: #94a3b8;">
                            <i class="fas fa-history" style="font-size: 60px; color: #e2e8f0; margin-bottom: 25px; display: block;"></i>
                            <div style="font-size: 18px; font-weight: 500;">No history found yet</div>
                            <p style="margin-top: 10px;">Your travel footprint will appear here once you start searching.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <script>
        function clearHistory() {
            if (confirm("Are you sure you want to clear your history?")) {
                window.location.href = "clear_history.php";
            }
        }
    </script>
</body>

</html>
