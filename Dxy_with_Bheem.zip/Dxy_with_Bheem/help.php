<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Guidelines - Dxy With Bheem</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="help.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="help-container" style="max-width: 1000px; margin: 0 auto; padding: 40px 20px;">
            <div class="back-link" style="margin-bottom: 30px;">
                <a href="home.php" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-weight: 600;">
                    <i class="fas fa-arrow-left"></i> Back to Home
                </a>
            </div>

            <section class="help-card" style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.1); margin-bottom: 40px;">
                <h2 style="font-size: 28px; margin-bottom: 20px; color: #1e293b;"><i class="fas fa-info-circle" style="color: #0072FF;"></i> How the App Works</h2>
                <p style="color: #64748b; font-size: 16px; line-height: 1.7;">Welcome to <strong>Dxy With Bheem</strong>, your ultimate companion for exploring the best travel
                    destinations. Our app integrates real-time mapping technology with a curated database of tourist
                    attractions to ensure you never miss out on a great experience.</p>

                <div class="help-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; margin-top: 40px;">
                    <div class="help-item" style="padding: 25px; background: #f8fafc; border-radius: 15px; border: 1px solid #e2e8f0; transition: all 0.3s ease;">
                        <i class="fas fa-map-marked-alt" style="font-size: 32px; color: #0072FF; margin-bottom: 15px; display: block;"></i>
                        <h3 style="font-size: 18px; margin-bottom: 10px; color: #1e293b;">Smart Routing</h3>
                        <p style="color: #64748b; font-size: 14px; line-height: 1.6;">We use high-precision routing engines to provide multiple path options, including the fastest and most scenic routes.</p>
                    </div>
                    <div class="help-item" style="padding: 25px; background: #f8fafc; border-radius: 15px; border: 1px solid #e2e8f0; transition: all 0.3s ease;">
                        <i class="fas fa-star" style="font-size: 32px; color: #0072FF; margin-bottom: 15px; display: block;"></i>
                        <h3 style="font-size: 18px; margin-bottom: 10px; color: #1e293b;">Curated Places</h3>
                        <p style="color: #64748b; font-size: 14px; line-height: 1.6;">Browse through categorized tourist attractions with detailed descriptions and ratings from other travelers.</p>
                    </div>
                    <div class="help-item" style="padding: 25px; background: #f8fafc; border-radius: 15px; border: 1px solid #e2e8f0; transition: all 0.3s ease;">
                        <i class="fas fa-history" style="font-size: 32px; color: #0072FF; margin-bottom: 15px; display: block;"></i>
                        <h3 style="font-size: 18px; margin-bottom: 10px; color: #1e293b;">History Sync</h3>
                        <p style="color: #64748b; font-size: 14px; line-height: 1.6;">Your search history is saved securely, allowing you to quickly revisit your favorite routes and locations.</p>
                    </div>
                </div>
            </section>

            <section class="help-card" style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.1);">
                <h2 style="font-size: 28px; margin-bottom: 30px; color: #1e293b;"><i class="fas fa-list-ol" style="color: #0072FF;"></i> Guidelines for Use</h2>
                <div class="guidelines" style="display: flex; flex-direction: column; gap: 40px;">
                    <div class="step" style="display: flex; gap: 20px; align-items: flex-start;">
                        <span class="step-num" style="width: 40px; height: 40px; background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 700; font-size: 18px;">1</span>
                        <div class="step-text">
                            <h4 style="font-size: 18px; margin-bottom: 8px; color: #1e293b;">Finding a Destination</h4>
                            <p style="color: #64748b; line-height: 1.6;">Use the search bar in the left sidebar to type any location. You can also visit the <strong>Tourist Places</strong> page to browse our recommendations.</p>
                        </div>
                    </div>
                    <div class="step" style="display: flex; gap: 20px; align-items: flex-start;">
                        <span class="step-num" style="width: 40px; height: 40px; background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 700; font-size: 18px;">2</span>
                        <div class="step-text">
                            <h4 style="font-size: 18px; margin-bottom: 8px; color: #1e293b;">Getting Directions</h4>
                            <p style="color: #64748b; line-height: 1.6;">Once you select a place, the map will automatically generate the best route from our main office. Use the "Use My Location" button to route from your current position.</p>
                        </div>
                    </div>
                    <div class="step" style="display: flex; gap: 20px; align-items: flex-start;">
                        <span class="step-num" style="width: 40px; height: 40px; background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 700; font-size: 18px;">3</span>
                        <div class="step-text">
                            <h4 style="font-size: 18px; margin-bottom: 8px; color: #1e293b;">Comparing Routes</h4>
                            <p style="color: #64748b; line-height: 1.6;">Look for the solid blue line for the primary route and dashed grey lines for alternative options. Click on any route to see distance and time estimates.</p>
                        </div>
                    </div>
                    <div class="step" style="display: flex; gap: 20px; align-items: flex-start;">
                        <span class="step-num" style="width: 40px; height: 40px; background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 700; font-size: 18px;">4</span>
                        <div class="step-text">
                            <h4 style="font-size: 18px; margin-bottom: 8px; color: #1e293b;">Giving Feedback</h4>
                            <p style="color: #64748b; line-height: 1.6;">Had a great trip? Visit the <strong>Feedback</strong> page in the right-side menu to share your experience with us!</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

</body>

</html>
