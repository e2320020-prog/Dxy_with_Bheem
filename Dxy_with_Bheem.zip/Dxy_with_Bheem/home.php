<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Home - Way to Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet"
        href="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.css" />
    <link rel="stylesheet" href="home.css">
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>
    <div class="side-bar-left">
        <div class="menu-icon">
            <i class="fas fa-bars"></i>
            <div class="left-dropdown">
                <a href="home.php"><i class="fas fa-home"></i> Home</a>
                <div class="sidebar-search-wrapper">
                    <div class="sidebar-search-container">
                        <i class="fas fa-search sidebar-search-icon"></i>
                        <input type="text" id="location-input" class="sidebar-search-input" placeholder="Search place...">
                        <button id="search-button" class="sidebar-search-btn" title="Search">
                            <i class="fas fa-arrow-right"></i>
                        </button>
                    </div>
                    <div id="search-results" class="sidebar-search-results"></div>
                </div>
                <button id="my-location-button" class="my-location-btn">
                    <i class="fas fa-location-arrow"></i> Use My Location
                </button>
                <a href="tourist places.php"><i class="fas fa-map-marker-alt"></i> Tourist Places</a>
                <a href="schedule.php"><i class="fas fa-calendar-alt"></i> Schedule Generator</a>
                <a href="view_schedules.php"><i class="fas fa-clipboard-list"></i> My Schedules</a>
            </div>
        </div>
    </div>
    <div class="side-bar-right">
        <div class="menu-icon">
            <i class="fas fa-bars"></i>
            <div class="dropdown">
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" style="background: rgba(255, 215, 0, 0.1); color: #ffd700;"><i class="fas fa-user-shield"></i> Admin Dashboard</a>
                <?php endif; ?>
                <a href="history.php"><i class="fas fa-history"></i> History</a>
                <a href="feedback.php"><i class="fas fa-comment"></i> Feedback</a>
                <a href="help.php"><i class="fas fa-question-circle"></i> Help</a>
            </div>
        </div>
    </div>

    <main class="main-content">
        <div class="map-container">
            <div id="map"></div>
        </div>
    </main>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
    <script src="sidebar.js"></script>
    <script src="Home.js"></script>
</body>

</html>

