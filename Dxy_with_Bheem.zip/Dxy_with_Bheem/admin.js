document.addEventListener('DOMContentLoaded', function () {
    
    const defaultAttractions = [
        { id: 1, name: "Panadura Beach", description: "Pristine golden sands, ideal for relaxing and kite flying.", icon: "fa-umbrella-beach", category: "beach", coordinates: [6.7132, 79.9026] },
        { id: 2, name: "Calido Beach", description: "Beautiful scenery and energetic atmosphere for water sports.", icon: "fa-water", category: "beach", coordinates: [6.7150, 79.9050] },
        { id: 3, name: "Richmond Castle", description: "Architectural marvel from the colonial era with lush greenery.", icon: "fa-fort-awesome", category: "heritage", coordinates: [6.5925, 79.9745] },
        { id: 4, name: "Kalutara Bodiya", description: "Significant Buddhist temple with an ancient sacred Bo tree.", icon: "fa-dharmachakra", category: "temple", coordinates: [6.5861, 79.9610] },
        { id: 5, name: "Rankoth Vihara", description: "Peaceful Buddhist retreat with unique architecture.", icon: "fa-vihara", category: "temple", coordinates: [6.7235, 79.9075] },
        { id: 6, name: "Bolgoda Lake", description: "Largest freshwater source, perfect for kayaking and birdwatching.", icon: "fa-ship", category: "nature", coordinates: [6.7333, 79.9167] },
        { id: 7, name: "Wadduwa Beach", description: "Top spot for a relaxing afternoon by the sea.", icon: "fa-sun", category: "beach", coordinates: [6.6667, 79.9333] },
        { id: 8, name: "Fishermen's Cove", description: "Authentic local experience at Panadura Beach.", icon: "fa-fish", category: "nature", coordinates: [6.7145, 79.9030] },
        { id: 9, name: "The Promenade", description: "Vibrant seaside garden area for relaxation.", icon: "fa-walking", category: "nature", coordinates: [6.7140, 79.9025] },
        { id: 10, name: "Gangaramaya Temple", description: "Traditional cultural site showcasing local heritage.", icon: "fa-vihara", category: "temple", coordinates: [6.7210, 79.9120] }
    ];

    let places = JSON.parse(localStorage.getItem('touristAttractions')) || defaultAttractions;
    let settings = JSON.parse(localStorage.getItem('appSettings')) || {
        themeColor: '#4285F4',
        sidebarGradient: 'linear-gradient(135deg, #8FC8FF 0%, #4285F4 100%)',
        bgUrl: ''
    };

    const placesList = document.getElementById('places-list');
    const addPlaceBtn = document.getElementById('add-place-btn');
    const placeModal = document.getElementById('place-modal');
    const closeModal = document.querySelector('.close-modal');
    const placeForm = document.getElementById('place-form');
    const editIdInput = document.getElementById('edit-id');
    const searchInput = document.getElementById('place-search');

    const themeColorInput = document.getElementById('theme-color');
    const bgUrlInput = document.getElementById('bg-url');
    const saveAppearanceBtn = document.getElementById('save-appearance');
    const resetAppearanceBtn = document.getElementById('reset-appearance');
    const gradientPresets = document.querySelectorAll('.preset-btn');


    function init() {
        renderPlaces();
        loadSettings();
    }

    function renderPlaces(filter = '') {
        placesList.innerHTML = '';
        const filtered = places.filter(p => p.name.toLowerCase().includes(filter.toLowerCase()));

        filtered.forEach(place => {
            const div = document.createElement('div');
            div.className = 'list-item';
            div.innerHTML = `
                <div class="item-info">
                    <h3>${place.name} <small>(${place.category})</small></h3>
                    <p>${place.description.substring(0, 60)}...</p>
                </div>
                <div class="item-actions">
                    <button class="action-btn edit-btn" onclick="editPlace(${place.id})"><i class="fas fa-edit"></i></button>
                    <button class="action-btn delete-btn" onclick="deletePlace(${place.id})"><i class="fas fa-trash"></i></button>
                </div>
            `;
            placesList.appendChild(div);
        });
    }

    window.deletePlace = function (id) {
        if (confirm('Delete this place?')) {
            places = places.filter(p => p.id !== id);
            savePlaces();
            renderPlaces();
        }
    };

    window.editPlace = function (id) {
        const place = places.find(p => p.id === id);
        if (place) {
            document.getElementById('modal-title').innerText = 'Edit Attraction';
            editIdInput.value = place.id;
            document.getElementById('place-name').value = place.name;
            document.getElementById('place-desc').value = place.description;
            document.getElementById('place-category').value = place.category;
            document.getElementById('place-icon').value = place.icon;
            document.getElementById('place-lat').value = place.coordinates[0];
            document.getElementById('place-lng').value = place.coordinates[1];
            placeModal.style.display = 'block';
        }
    };

    function savePlaces() {
        localStorage.setItem('touristAttractions', JSON.stringify(places));
    }

    addPlaceBtn.onclick = () => {
        document.getElementById('modal-title').innerText = 'Add New Attraction';
        placeForm.reset();
        editIdInput.value = '';
        placeModal.style.display = 'block';
    };

    closeModal.onclick = () => placeModal.style.display = 'none';
    window.onclick = (e) => { if (e.target == placeModal) placeModal.style.display = 'none'; };

    placeForm.onsubmit = (e) => {
        e.preventDefault();
        const id = editIdInput.value ? parseInt(editIdInput.value) : Date.now();
        const newPlace = {
            id: id,
            name: document.getElementById('place-name').value,
            description: document.getElementById('place-desc').value,
            category: document.getElementById('place-category').value,
            icon: document.getElementById('place-icon').value || 'fa-map-marker-alt',
            coordinates: [
                parseFloat(document.getElementById('place-lat').value),
                parseFloat(document.getElementById('place-lng').value)
            ]
        };

        if (editIdInput.value) {
            const index = places.findIndex(p => p.id === id);
            places[index] = newPlace;
        } else {
            places.push(newPlace);
        }

        savePlaces();
        renderPlaces();
        placeModal.style.display = 'none';
    };

    searchInput.oninput = (e) => renderPlaces(e.target.value);

    function loadSettings() {
        themeColorInput.value = settings.themeColor;
        bgUrlInput.value = settings.bgUrl;
    }

    gradientPresets.forEach(btn => {
        btn.onclick = () => {
            settings.sidebarGradient = btn.getAttribute('data-gradient');
            gradientPresets.forEach(b => b.style.outline = 'none');
            btn.style.outline = '3px solid var(--primary-color)';
        };
    });

    saveAppearanceBtn.onclick = () => {
        settings.themeColor = themeColorInput.value;
        settings.bgUrl = bgUrlInput.value;
        localStorage.setItem('appSettings', JSON.stringify(settings));
        alert('Appearance settings saved! Changes will take effect on next reload.');
    };

    resetAppearanceBtn.onclick = () => {
        if (confirm('Reset to default appearance?')) {
            localStorage.removeItem('appSettings');
            location.reload();
        }
    };

    init();
});

