<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $message = mysqli_real_escape_string($conn, $data['message']);
    $rating = (int)$data['rating'];

    $user_id = $_SESSION['user_id'];
    $role = $_SESSION['role'];
    $name = isset($_SESSION['username']) ? mysqli_real_escape_string($conn, $_SESSION['username']) : 'Anonymous';
    
    $email = 'unknown@example.com';
    if ($role === 'admin') {
        $adminRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT email FROM admin WHERE id = $user_id LIMIT 1"));
        if ($adminRow) $email = mysqli_real_escape_string($conn, $adminRow['email']);
    } else {
        $userRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT email FROM users WHERE id = $user_id LIMIT 1"));
        if ($userRow) $email = mysqli_real_escape_string($conn, $userRow['email']);
    }

    $sql = "INSERT INTO feedback (user_id, user_role, name, email, message, rating) 
            VALUES ('$user_id', '$role', '$name', '$email', '$message', '$rating')";

    if (mysqli_query($conn, $sql)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
    }
}
?>
