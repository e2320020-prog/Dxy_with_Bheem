<?php
require_once 'db_connect.php';
$statusMsg = "";
$statusClass = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $user_type = $_POST['user_type'];
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $statusMsg = "Passwords do not match!";
        $statusClass = "status-error";
    } else {
        if ($user_type === 'admin') {
            $check_sql = "SELECT id FROM `admin` WHERE username = '$username'";
        } else {
            $check_sql = "SELECT id FROM `users` WHERE username = '$username'";
        }
        
        $check_result = mysqli_query($conn, $check_sql);
        if (mysqli_num_rows($check_result) > 0) {
            $statusMsg = "Username already exists! Please choose a different username.";
            $statusClass = "status-error";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            if ($user_type === 'admin') {
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $sql = "INSERT INTO `admin` (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
            } else {
                $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
                $email = mysqli_real_escape_string($conn, $_POST['email']);
                $sql = "INSERT INTO `users` (fullname, email, username, password) VALUES ('$fullname', '$email', '$username', '$hashed_password')";
            }

            if (mysqli_query($conn, $sql)) {
                $statusMsg = "Registration successful as " . ucfirst($user_type) . "! Redirecting to login...";
                $statusClass = "status-success";
                header("refresh:2;url=login.php");
            } else {
                $statusMsg = "Error: " . mysqli_error($conn);
                $statusClass = "status-error";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Dxy With Bheem</title>
    <link rel="stylesheet" href="auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .input-wrapper select {
            width: 100%;
            padding: 14px 15px 14px 50px;
            border: 2px solid #f1f5f9;
            border-radius: 12px;
            font-size: 15px;
            font-family: inherit;
            background: #f8fafc;
            color: #1e293b;
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
            transition: all 0.3s ease;
        }
        .input-wrapper select:focus {
            border-color: #00C6FF;
            outline: none;
            background: white;
            box-shadow: 0 0 0 4px rgba(0, 198, 255, 0.08);
        }
        .select-arrow {
            position: absolute;
            right: 18px;
            pointer-events: none;
            color: #94a3b8;
        }
    </style>
</head>

<body>
    <div class="auth-container" style="max-width: 480px;">
        <div class="brand-heading">Dxy With Bheem</div>
        <div class="auth-header">
            <i class="fas fa-user-plus"></i>
            <h2>Create Account</h2>
            <p>Join our smart travel community today</p>
        </div>

        <form id="register-form" method="POST" action="register.php">
            <div class="form-group">
                <label for="user_type">I want to join as...</label>
                <div class="input-wrapper">
                    <i class="fas fa-user-tag input-icon"></i>
                    <select id="user_type" name="user_type" required onchange="toggleFields()">
                        <option value="user">Regular Explorer</option>
                        <option value="admin">Site Administrator</option>
                    </select>
                    <i class="fas fa-chevron-down select-arrow"></i>
                </div>
            </div>

            <div id="fullname-field">
                <div class="form-group">
                    <label for="fullname">Full Name</label>
                    <div class="input-wrapper">
                        <i class="fas fa-id-card input-icon"></i>
                        <input type="text" id="fullname" name="fullname" placeholder="John Doe">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-wrapper">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" id="email" name="email" placeholder="explorer@example.com" required>
                </div>
            </div>

            <div class="form-group">
                <label for="username">Choose Username</label>
                <div class="input-wrapper">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="username" name="username" placeholder="Unique username" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" id="password" name="password" placeholder="6+ chars" required minlength="6">
                        <i class="fas fa-eye toggle-password" onclick="togglePassword('password', this)"></i>
                    </div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm</label>
                    <div class="input-wrapper">
                        <i class="fas fa-check-double input-icon"></i>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Repeat" required minlength="6">
                    </div>
                </div>
            </div>

            <button type="submit" name="register" class="auth-btn">Save and Register</button>
            <?php if ($statusMsg): ?>
                <div id="status-msg" class="status-msg <?php echo $statusClass; ?>" style="display: block;"><?php echo $statusMsg; ?></div>
            <?php endif; ?>
        </form>

        <div class="auth-footer">
            Already have an account? <a href="login.php">Log In</a>
        </div>
    </div>

    <script>
        function toggleFields() {
            const userType = document.getElementById('user_type').value;
            const fullnameField = document.getElementById('fullname-field');
            const fullnameInput = document.getElementById('fullname');

            if (userType === 'admin') {
                fullnameField.style.display = 'none';
                fullnameInput.required = false;
            } else {
                fullnameField.style.display = 'block';
                fullnameInput.required = true;
            }
        }

        function togglePassword(id, icon) {
            const el = document.getElementById(id);
            if (el.type === "password") {
                el.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                el.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }

        window.onload = toggleFields;
    </script>
</body>

</html>
