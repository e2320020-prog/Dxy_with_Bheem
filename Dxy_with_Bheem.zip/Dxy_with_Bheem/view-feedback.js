document.addEventListener('DOMContentLoaded', function () {
    const feedbackList = document.getElementById('feedback-list');

    function renderFeedbacks() {
        const feedbacks = JSON.parse(localStorage.getItem('feedbacks')) || [];

        if (feedbacks.length === 0) {
            feedbackList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-comment-slash"></i>
                    <p>No feedbacks yet. Your submissions will appear here.</p>
                </div>
            `;
            return;
        }

        feedbacks.sort((a, b) => new Date(b.date) - new Date(a.date));

        feedbackList.innerHTML = feedbacks.map(item => `
            <div class="feedback-item">
                <div class="feedback-header">
                    <div class="user-info">
                        <strong>${escapeHTML(item.name)}</strong>
                        <span>${escapeHTML(item.email)}</span>
                    </div>
                    <div class="rating-display">
                        ${generateStars(item.rating)}
                    </div>
                </div>
                <div class="feedback-body">
                    <p>${escapeHTML(item.message)}</p>
                </div>
                <div class="feedback-footer">
                    <small>${new Date(item.date).toLocaleString()}</small>
                </div>
            </div>
        `).join('');
    }

    function generateStars(rating) {
        let stars = '';
        const r = parseInt(rating) || 0;
        for (let i = 1; i <= 5; i++) {
            stars += `<i class="fa${i <= r ? 's' : 'r'} fa-star"></i>`;
        }
        return stars;
    }

    function escapeHTML(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    setTimeout(renderFeedbacks, 800); // Small delay for effect
});

