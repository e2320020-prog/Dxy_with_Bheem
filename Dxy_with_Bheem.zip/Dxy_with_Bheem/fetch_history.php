<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 5;

$sql = "SELECT location_name as LocationName, created_at as CreatedAt, search_type as SearchType FROM `history` 
        WHERE user_id = '$user_id' AND user_type = '$role' 
        ORDER BY created_at DESC LIMIT $limit";
$result = mysqli_query($conn, $sql);

$history = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $history[] = $row;
    }
}

echo json_encode($history);
?>

