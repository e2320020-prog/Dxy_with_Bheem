<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

$sql = "SELECT id, name, description, category, icon, location_link, latitude, longitude FROM `tourist_places` ORDER BY name ASC";
$result = mysqli_query($conn, $sql);

$attractions = [];
while ($row = mysqli_fetch_assoc($result)) {
    $attractions[] = $row;
}

echo json_encode($attractions);
?>

