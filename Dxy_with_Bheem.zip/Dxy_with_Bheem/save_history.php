<?php
session_start();
require_once 'db_connect.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $user_type = $_SESSION['role'];
    $search_type = mysqli_real_escape_string($conn, $data['searchType'] ?? 'search');
    $location_name = mysqli_real_escape_string($conn, $data['locationName'] ?? 'Unknown');
    $lat = isset($data['lat']) ? (float)$data['lat'] : 'NULL';
    $lng = isset($data['lng']) ? (float)$data['lng'] : 'NULL';

    $sql = "INSERT INTO `history` (user_type, user_id, search_type, location_name, lat, lng) 
            VALUES ('$user_type', '$user_id', '$search_type', '$location_name', $lat, $lng)";
            
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
    }
}
?>

