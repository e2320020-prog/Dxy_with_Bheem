<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$colsResult = mysqli_query($conn, "SHOW COLUMNS FROM feedback");
$cols = [];
while ($row = mysqli_fetch_assoc($colsResult)) {
    $cols[] = $row['Field'];
}

if (in_array('user_id', $cols) && in_array('user_role', $cols)) {
    $sql = "SELECT f.*, 
           CASE 
             WHEN f.user_role = 'admin' THEN a.username 
             ELSE u.username 
           END as username 
        FROM feedback f 
        LEFT JOIN users u ON f.user_id = u.id AND f.user_role = 'user'
        LEFT JOIN admin a ON f.user_id = a.id AND f.user_role = 'admin'
        ORDER BY f.created_at DESC";
} elseif (in_array('name', $cols) && in_array('email', $cols)) {
    $sql = "SELECT id, name AS username, email, message, rating, created_at FROM feedback ORDER BY created_at DESC";
} else {
    die("Error: Unsupported feedback table schema");
}

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error fetching feedback: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Feedback - Dxy With Bheem</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .feedback-view-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .view-title {
            font-size: 32px;
            color: #1e293b;
            margin-bottom: 35px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .feedback-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
        }

        .feedback-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            border: 1px solid #f1f5f9;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .feedback-card:hover {
            transform: translateY(-5px);
            border-color: #0072FF;
            box-shadow: 0 15px 45px rgba(0, 114, 255, 0.1);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: #e0f2fe;
            color: #0072FF;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .user-name {
            font-weight: 800;
            color: #1e293b;
            font-size: 16px;
        }

        .date-sent {
            font-size: 12px;
            color: #94a3b8;
            font-weight: 600;
        }

        .stars-row {
            color: #fbbf24;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .feedback-text {
            color: #475569;
            line-height: 1.6;
            font-size: 15px;
            font-style: italic;
            background: #f8fafc;
            padding: 15px;
            border-radius: 12px;
        }
    </style>
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info-header" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <div class="side-bar-left">
        <div class="menu-icon">
            <i class="fas fa-bars"></i>
            <div class="left-dropdown">
                <a href="home.php"><i class="fas fa-home"></i> Home</a>
                <a href="tourist places.php"><i class="fas fa-map-marker-alt"></i> Tourist Places</a>
                <a href="history.php"><i class="fas fa-history"></i> History</a>
                <a href="schedule.php"><i class="fas fa-calendar-alt"></i> Schedule Generator</a>
                <a href="view_schedules.php"><i class="fas fa-clipboard-list"></i> My Schedules</a>
            </div>
        </div>
    </div>

    <div class="side-bar-right">
        <div class="menu-icon">
            <i class="fas fa-bars"></i>
            <div class="dropdown">
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" style="background: rgba(255, 215, 0, 0.1); color: #ffd700;"><i class="fas fa-user-shield"></i> Admin Dashboard</a>
                <?php endif; ?>
                <a href="feedback.php" class="active"><i class="fas fa-comment"></i> Feedback</a>
                <a href="help.php"><i class="fas fa-question-circle"></i> Help</a>
            </div>
        </div>
    </div>

    <main class="main-content">
        <div class="feedback-view-container">
            <div class="back-link" style="margin-bottom: 30px;">
                <a href="javascript:history.back()" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-weight: 600;">
                    <i class="fas fa-arrow-left"></i> Go Back
                </a>
            </div>

            <h1 class="view-title"><i class="fas fa-quote-left" style="color: #0072FF;"></i> Community Wall</h1>

            <div class="feedback-grid">
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <div class="feedback-card">
                            <div class="card-header">
                                <div class="user-info">
                                    <div class="user-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div>
                                        <div class="user-name"><?php echo htmlspecialchars($row['username']); ?></div>
                                        <div class="date-sent"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="stars-row">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star" style="color: <?php echo ($i <= $row['rating']) ? '#fbbf24' : '#e2e8f0'; ?>;"></i>
                                <?php endfor; ?>
                            </div>
                            <div class="feedback-text">
                                "<?php echo htmlspecialchars($row['message']); ?>"
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="grid-column: 1 / -1; text-align: center; padding: 60px; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                        <i class="fas fa-comment-slash" style="font-size: 60px; color: #e2e8f0; margin-bottom: 20px; display: block;"></i>
                        <h3 style="color: #64748b;">No feedback found.</h3>
                        <p style="color: #94a3b8; margin-top: 10px;">Be the first one to share your experience!</p>
                        <a href="feedback.php" class="btn-create" style="margin-top: 25px; display: inline-block; background: #0072FF; color: white; padding: 12px 30px; border-radius: 12px; text-decoration: none; font-weight: 700;">Rate My Experience</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="sidebar.js"></script>
</body>

</html>
