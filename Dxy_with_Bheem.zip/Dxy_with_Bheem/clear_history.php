<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "DELETE FROM history WHERE user_id = '$user_id'";

if (mysqli_query($conn, $sql)) {
    header("Location: history.php");
} else {
    echo "Error clearing history: " . mysqli_error($conn);
}
?>
