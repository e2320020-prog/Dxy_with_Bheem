
document.addEventListener('DOMContentLoaded', () => {
    renderHistory();

    const clearBtn = document.getElementById('clear-history-btn');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to clear your entire travel history?')) {
                localStorage.removeItem('searchHistory');
                renderHistory();
            }
        });
    }
});

function renderHistory() {
    const historyData = localStorage.getItem('searchHistory');
    const history = historyData ? JSON.parse(historyData) : [];
    const container = document.getElementById('history-list');

    if (!container) return;

    if (history.length === 0) {
        container.innerHTML = '<div class="empty-msg">No history found yet. Start exploring from the home page!</div>';
        return;
    }

    container.innerHTML = '';

    history.forEach((item, index) => {
        const date = new Date(item.CreatedAt);
        const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        const typeIcon = item.SearchType === 'selection' ? 'fa-map-pin' : 'fa-search';

        const itemDiv = document.createElement('div');
        itemDiv.className = 'history-item';
        // Add animation delay for staggered effect
        itemDiv.style.animationDelay = `${index * 0.05}s`;
        itemDiv.innerHTML = `
            <div class="item-info">
                <div class="item-icon">
                    <i class="fas ${typeIcon}"></i>
                </div>
                <div class="item-details">
                    <h4>${item.LocationName}</h4>
                    <p><i class="far fa-clock"></i> ${formattedDate}</p>
                </div>
            </div>
            <div class="item-actions">
                <i class="fas fa-chevron-right"></i>
            </div>
        `;

        itemDiv.onclick = () => {
            window.location.href = `home.php?search=${encodeURIComponent(item.LocationName)}`;
        };

        container.appendChild(itemDiv);
    });
}

