<?php
require_once 'db_connect.php';

$tables = [
    "users" => "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        fullname VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "admin" => "CREATE TABLE IF NOT EXISTS admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "tourist_places" => "CREATE TABLE IF NOT EXISTS tourist_places (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        category VARCHAR(50),
        icon VARCHAR(50),
        latitude DECIMAL(10, 8),
        longitude DECIMAL(11, 8),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "history" => "CREATE TABLE IF NOT EXISTS history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        user_type ENUM('user', 'admin') DEFAULT 'user',
        location_name VARCHAR(100),
        lat DECIMAL(10, 8),
        lng DECIMAL(11, 8),
        search_type ENUM('search', 'selection') DEFAULT 'search',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "feedback" => "CREATE TABLE IF NOT EXISTS feedback (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        user_role ENUM('user', 'admin') DEFAULT 'user',
        name VARCHAR(100),
        email VARCHAR(100),
        message TEXT,
        rating INT DEFAULT 5,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "schedules" => "CREATE TABLE IF NOT EXISTS schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        username VARCHAR(100) NOT NULL,
        user_role ENUM('user', 'admin') DEFAULT 'user',
        schedule_name VARCHAR(255) NOT NULL,
        place_1 INT,
        place_2 INT,
        place_3 INT,
        place_4 INT,
        place_5 INT,
        place_6 INT,
        place_7 INT,
        place_8 INT,
        place_9 INT,
        place_10 INT,
        time_1 TIME,
        time_2 TIME,
        time_3 TIME,
        time_4 TIME,
        time_5 TIME,
        time_6 TIME,
        time_7 TIME,
        time_8 TIME,
        time_9 TIME,
        time_10 TIME,
        starting_time TIME,
        finishing_time TIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )"
];

foreach ($tables as $name => $sql) {
    if (mysqli_query($conn, $sql)) {
        echo "Table '$name' checked/created successfully.<br>";
    } else {
        echo "Error creating table '$name': " . mysqli_error($conn) . "<br>";
    }
}

$alterSql = "ALTER TABLE tourist_places ADD COLUMN IF NOT EXISTS location_link VARCHAR(255) AFTER longitude";
if (mysqli_query($conn, $alterSql)) {
    echo "Column 'location_link' added to 'tourist_places' successfully.<br>";
} else {
    echo "Error adding column: " . mysqli_error($conn) . "<br>";
}

$alterSql1 = "ALTER TABLE schedules ADD COLUMN IF NOT EXISTS starting_time TIME AFTER place_10";
if (mysqli_query($conn, $alterSql1)) {
    echo "Column 'starting_time' added to 'schedules' successfully.<br>";
} else {
    echo "Error adding column 'starting_time': " . mysqli_error($conn) . "<br>";
}

$alterSql2 = "ALTER TABLE schedules ADD COLUMN IF NOT EXISTS finishing_time TIME AFTER starting_time";
if (mysqli_query($conn, $alterSql2)) {
    echo "Column 'finishing_time' added to 'schedules' successfully.<br>";
} else {
    echo "Error adding column 'finishing_time': " . mysqli_error($conn) . "<br>";
}

$historyAlters = [
    "ALTER TABLE history ADD COLUMN IF NOT EXISTS user_type ENUM('user', 'admin') DEFAULT 'user' AFTER user_id",
    "ALTER TABLE history ADD COLUMN IF NOT EXISTS location_name VARCHAR(100) AFTER user_type",
    "ALTER TABLE history ADD COLUMN IF NOT EXISTS lat DECIMAL(10, 8) AFTER location_name",
    "ALTER TABLE history ADD COLUMN IF NOT EXISTS lng DECIMAL(11, 8) AFTER lat",
    "ALTER TABLE history ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER search_type"
];

foreach ($historyAlters as $sql) {
    mysqli_query($conn, $sql);
}
echo "History table schema synchronized.<br>";

$feedbackAlters = [
    "ALTER TABLE feedback ADD COLUMN IF NOT EXISTS name VARCHAR(100) AFTER user_role",
    "ALTER TABLE feedback ADD COLUMN IF NOT EXISTS email VARCHAR(100) AFTER name"
];

foreach ($feedbackAlters as $sql) {
    mysqli_query($conn, $sql);
}
echo "Feedback table schema synchronized.<br>";

for ($i = 1; $i <= 10; $i++) {
    $alterSql = "ALTER TABLE schedules ADD COLUMN IF NOT EXISTS time_$i TIME AFTER place_$i";
    if (mysqli_query($conn, $alterSql)) {
        echo "Column 'time_$i' added to 'schedules' successfully.<br>";
    } else {
        echo "Error adding column 'time_$i': " . mysqli_error($conn) . "<br>";
    }
}

$checkAdmin = mysqli_query($conn, "SELECT id FROM admin WHERE username = 'admin'");
if (mysqli_num_rows($checkAdmin) == 0) {
    $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $sql = "INSERT INTO admin (username, email, password) 
            VALUES ('admin', 'admin@example.com', '$adminPassword')";
    if (mysqli_query($conn, $sql)) {
        echo "Default admin account created (admin/admin123).<br>";
    }
}

$checkPlaces = mysqli_query($conn, "SELECT id FROM tourist_places LIMIT 1");
if (mysqli_num_rows($checkPlaces) == 0) {
    $defaultPlaces = [
        ['Panadura Beach', 'Pristine golden sands, ideal for relaxing and kite flying.', 'beach', 'fa-umbrella-beach', 6.7132, 79.9026, NULL],
        ['Calido Beach', 'Beautiful scenery and energetic atmosphere for water sports.', 'beach', 'fa-water', 6.7150, 79.9050, NULL],
        ['Richmond Castle', 'Architectural marvel from the colonial era with lush greenery.', 'heritage', 'fa-fort-awesome', 6.5925, 79.9745, NULL],
        ['Kalutara Bodiya', 'Significant Buddhist temple with an ancient sacred Bo tree.', 'temple', 'fa-dharmachakra', 6.5861, 79.9610, NULL],
        ['Rankoth Vihara', 'Peaceful Buddhist retreat with unique architecture.', 'temple', 'fa-vihara', 6.7235, 79.9075, NULL],
        ['Bolgoda Lake', 'Largest freshwater source, perfect for kayaking and birdwatching.', 'nature', 'fa-ship', 6.7333, 79.9167, NULL],
        ['Wadduwa Beach', 'Top spot for a relaxing afternoon by the sea.', 'beach', 'fa-sun', 6.6667, 79.9333, NULL],
        ['Fishermen\'s Cove', 'Authentic local experience at Panadura Beach.', 'nature', 'fa-fish', 6.7145, 79.9030, NULL],
        ['The Promenade', 'Vibrant seaside garden area for relaxation.', 'nature', 'fa-walking', 6.7140, 79.9025, NULL],
        ['Gangaramaya Temple', 'Traditional cultural site showcasing local heritage.', 'temple', 'fa-vihara', 6.7210, 79.9120, NULL]
    ];

    $stmt = mysqli_prepare($conn, "INSERT INTO tourist_places (name, description, category, icon, latitude, longitude, location_link) VALUES (?, ?, ?, ?, ?, ?, ?)");
    foreach ($defaultPlaces as $place) {
        $location_link = $place[6];
        mysqli_stmt_bind_param($stmt, "ssssdds", $place[0], $place[1], $place[2], $place[3], $place[4], $place[5], $location_link);
        mysqli_stmt_execute($stmt);
    }
    echo "Default tourist places seeded.<br>";
}

mysqli_close($conn);
?>

