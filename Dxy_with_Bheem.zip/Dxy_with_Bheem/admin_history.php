<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT h.id, h.user_id, h.user_type, h.location_name, h.search_type, h.created_at,
            CASE 
                WHEN h.user_type = 'admin' THEN (SELECT username FROM `admin` a WHERE a.id = h.user_id)
                ELSE (SELECT username FROM `users` u WHERE u.id = h.user_id)
            END as username
        FROM `history` h
        ORDER BY h.created_at DESC";

$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Search History - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="home.css">
    <style>
        .admin-view-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .admin-view-card {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }

        .admin-view-title {
            font-size: 32px;
            color: #1e293b;
            margin-bottom: 30px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .history-grid {
            display: grid;
            gap: 15px;
            margin-top: 30px;
        }

        .admin-history-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px;
            background: #f8fafc;
            border-radius: 15px;
            border: 1px solid #e2e8f0;
            transition: transform 0.2s;
        }

        .admin-history-item:hover {
            transform: translateX(10px);
            border-color: #0072FF;
        }

        .info-content {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .location-name {
            font-weight: 800;
            color: #1e293b;
            font-size: 16px;
        }

        .user-tag {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            padding: 3px 10px;
            border-radius: 20px;
            background: #e0f2fe;
            color: #0369a1;
            width: fit-content;
        }

        .admin-tag {
            background: #fef3c7;
            color: #92400e;
        }

        .timestamp {
            font-size: 13px;
            color: #64748b;
        }
    </style>
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Administrator Insights</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="admin-view-container">
            <div class="admin-view-card">
                <div class="back-link" style="margin-bottom: 30px;">
                    <a href="admin.php" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-weight: 600;">
                        <i class="fas fa-arrow-left"></i> Back to Dashboard
                    </a>
                </div>

                <h1 class="admin-view-title"><i class="fas fa-history" style="color: #0072FF;"></i> Global Search History</h1>

                <div class="history-grid">
                    <?php if ($result && mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <div class="admin-history-item">
                                <div class="info-content">
                                    <div class="location-name"><?php echo htmlspecialchars($row['location_name']); ?></div>
                                    <div style="display: flex; gap: 10px; align-items: center; margin-top: 5px;">
                                        <div class="user-tag <?php echo $row['user_type'] === 'admin' ? 'admin-tag' : ''; ?>">
                                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($row['username'] ?? 'User #'.$row['user_id']); ?>
                                        </div>
                                        <div class="timestamp"><i class="fas fa-calendar-alt"></i> <?php echo date('M d, Y - H:i', strtotime($row['created_at'])); ?></div>
                                    </div>
                                </div>
                                <div style="color: #e2e8f0;"><i class="fas fa-chevron-right"></i></div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div style="text-align: center; padding: 40px; color: #94a3b8;">
                            <i class="fas fa-inbox" style="font-size: 40px; margin-bottom: 15px; display: block;"></i>
                            No search history records found.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

</body>

</html>
