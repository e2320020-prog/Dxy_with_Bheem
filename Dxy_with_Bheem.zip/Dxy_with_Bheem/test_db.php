<?php
$conn = mysqli_connect("localhost", "root", "");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$dbname = "way to home";
$output = "";
if (mysqli_select_db($conn, $dbname)) {
    $output .= "Connected to database: $dbname\n";
    
    $check_col = mysqli_query($conn, "SHOW COLUMNS FROM `admin` WHERE Field='email'");
    if (mysqli_num_rows($check_col) == 0) {
        mysqli_query($conn, "ALTER TABLE `admin` ADD COLUMN `email` VARCHAR(100) AFTER `username`") or $output .= "Alter failed: " . mysqli_error($conn) . "\n";
        $output .= "Email column added to admin table\n";
    } else {
        $output .= "Email column already exists in admin table\n";
    }
    
    $result = mysqli_query($conn, "SHOW TABLES");
    while ($row = mysqli_fetch_row($result)) {
        $output .= "Table: " . $row[0] . "\n";
        $columns = mysqli_query($conn, "SHOW COLUMNS FROM `" . $row[0] . "`");
        while ($col = mysqli_fetch_assoc($columns)) {
            $output .= "  - " . $col['Field'] . " (" . $col['Type'] . ")\n";
        }
    }
} else {
    $output .= "Database $dbname does not exist.\n";
}
file_put_contents("db_structure.txt", $output);
echo "Structure saved to db_structure.txt\n";
?>


