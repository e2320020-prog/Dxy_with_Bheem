<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SESSION['role'] === 'admin') {
    $query = "SELECT * FROM schedules ORDER BY created_at DESC";
} else {
    $query = "SELECT * FROM schedules WHERE user_id = {$_SESSION['user_id']} ORDER BY created_at DESC";
}

$schedulesResult = mysqli_query($conn, $query);
$schedules = [];
if ($schedulesResult) {
    while ($schedule = mysqli_fetch_assoc($schedulesResult)) {
        $schedules[] = $schedule;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $schedule_id = (int)$_POST['schedule_id'];
    $check_schedule = mysqli_fetch_assoc(mysqli_query($conn, "SELECT user_id FROM schedules WHERE id = $schedule_id"));

    if ($_SESSION['role'] === 'admin' || ($check_schedule && $check_schedule['user_id'] == $_SESSION['user_id'])) {
        if (mysqli_query($conn, "DELETE FROM schedules WHERE id = $schedule_id")) {
            $success_msg = "Schedule deleted successfully!";
        } else {
            $error_msg = "Error deleting schedule: " . mysqli_error($conn);
        }
    } else {
        $error_msg = "You don't have permission to delete this schedule!";
    }
}

$placesResult = mysqli_query($conn, "SELECT id, name FROM tourist_places");
$places = [];
if ($placesResult) {
    while ($place = mysqli_fetch_assoc($placesResult)) {
        $places[$place['id']] = $place['name'];
    }
}

function getPlaceNames($schedule, $places) {
    $placeNames = [];
    for ($i = 1; $i <= 10; $i++) {
        $place_id = $schedule["place_$i"];
        if ($place_id && isset($places[$place_id])) {
            $placeNames[] = $places[$place_id];
        }
    }
    return count($placeNames) > 0 ? implode(" → ", $placeNames) : "No itinerary defined";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Schedules - Dxy With Bheem</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .view-container {
            max-width: 1100px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .view-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .view-header h2 {
            font-size: 32px;
            color: #1e293b;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-create {
            background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%);
            color: white;
            padding: 12px 25px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
            box-shadow: 0 4px 12px rgba(0, 114, 255, 0.2);
        }

        .btn-create:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 18px rgba(0, 114, 255, 0.3);
        }

        .schedule-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            border: 1px solid #f1f5f9;
            transition: border-color 0.3s;
        }

        .schedule-card:hover {
            border-color: #00C6FF;
        }

        .card-meta {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #f1f5f9;
            color: #64748b;
            font-size: 14px;
            flex-wrap: wrap;
        }

        .meta-item i {
            color: #0072FF;
            margin-right: 5px;
        }

        .itinerary-box {
            padding: 15px;
            background: #f8fafc;
            border-radius: 12px;
            margin-bottom: 25px;
            border-left: 5px solid #00C6FF;
        }

        .timers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .timer-unit {
            padding: 20px;
            background: #fff;
            border: 2px solid #f1f5f9;
            border-radius: 15px;
            text-align: center;
        }

        .countdown-display {
            font-size: 28px;
            font-weight: 800;
            color: #1e293b;
            font-family: 'Courier New', Courier, monospace;
            display: block;
            margin: 15px 0;
            background: #f8fafc;
            padding: 10px;
            border-radius: 10px;
        }

        .timer-controls {
            display: flex;
            gap: 8px;
            justify-content: center;
        }

        .control-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 700;
            transition: background 0.2s;
        }

        .btn-start { background: #dcfce7; color: #166534; }
        .btn-pause { background: #fef3c7; color: #92400e; }
        .btn-reset { background: #fee2e2; color: #b91c1c; }

        .btn-delete {
            background: #ef4444;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 700;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="view-container">
            <div class="view-header">
                <h2><i class="fas fa-clipboard-list" style="color: #0072FF;"></i> <?php echo $_SESSION['role'] === 'admin' ? 'Total Fleet Schedules' : 'My Travel Itineraries'; ?></h2>
                <a href="schedule.php" class="btn-create"><i class="fas fa-plus"></i> Design New Schedule</a>
            </div>

            <?php if (count($schedules) > 0): ?>
                <?php foreach ($schedules as $schedule): ?>
                    <div class="schedule-card">
                        <div style="display: flex; justify-content: space-between; align-items: start;">
                            <h3 style="font-size: 24px; color: #1e293b; margin: 0 0 10px 0;"><?php echo htmlspecialchars($schedule['schedule_name']); ?></h3>
                            <form method="POST" onsubmit="return confirm('Delete this schedule permanently?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="schedule_id" value="<?php echo $schedule['id']; ?>">
                                <button type="submit" class="btn-delete"><i class="fas fa-trash-alt"></i></button>
                            </form>
                        </div>

                        <div class="card-meta">
                            <div class="meta-item"><i class="fas fa-clock"></i> Window: <?php echo date('H:i', strtotime($schedule['starting_time'])); ?> - <?php echo date('H:i', strtotime($schedule['finishing_time'])); ?></div>
                            <div class="meta-item"><i class="fas fa-calendar-alt"></i> Saved: <?php echo date('M j, Y', strtotime($schedule['created_at'])); ?></div>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                                <div class="meta-item"><i class="fas fa-user"></i> By: <?php echo htmlspecialchars($schedule['username']); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="itinerary-box">
                            <div style="font-weight: 700; color: #1e293b; margin-bottom: 10px; font-size: 14px; text-transform: uppercase;">Path</div>
                            <div style="color: #475569; font-weight: 600;"><?php echo htmlspecialchars(getPlaceNames($schedule, $places)); ?></div>
                        </div>

                        <div class="timers-grid">
                            <?php for ($i = 1; $i <= 10; $i++): 
                                if ($schedule["place_$i"]): ?>
                                    <div class="timer-unit" id="timer-unit-<?php echo $schedule['id']; ?>-<?php echo $i; ?>">
                                        <div style="font-weight: 800; color: #1e293b;"><?php echo htmlspecialchars($places[$schedule["place_$i"]] ?? 'Unknown'); ?></div>
                                        <div style="font-size: 12px; color: #64748b; margin-top: 5px;">Allocation #<?php echo $i; ?></div>
                                        <span class="countdown-display" id="count-<?php echo $schedule['id']; ?>-<?php echo $i; ?>">
                                            <?php echo $schedule["time_$i"] ? date('H:i:s', strtotime($schedule["time_$i"])) : '00:00:00'; ?>
                                        </span>
                                        <div class="timer-controls">
                                            <button class="control-btn btn-start" onclick="timerControl.start('<?php echo $schedule['id']; ?>-<?php echo $i; ?>')">Start</button>
                                            <button class="control-btn btn-pause" onclick="timerControl.pause('<?php echo $schedule['id']; ?>-<?php echo $i; ?>')">Pause</button>
                                            <button class="control-btn btn-reset" onclick="timerControl.reset('<?php echo $schedule['id']; ?>-<?php echo $i; ?>', '<?php echo $schedule["time_$i"]; ?>')">Reset</button>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 60px; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                    <i class="fas fa-clipboard-list" style="font-size: 60px; color: #e2e8f0; margin-bottom: 20px; display: block;"></i>
                    <h3 style="color: #64748b;">No schedules yet.</h3>
                    <p style="color: #94a3b8; margin: 10px 0 25px;">Create your first travel itinerary to track your journey.</p>
                    <a href="schedule.php" class="btn-create">Design New Schedule</a>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script>
        const timerControl = {
            activeIntervals: {},
            remainingSeconds: {},

            start(id) {
                if (this.activeIntervals[id]) return;
                
                const element = document.getElementById('count-' + id);
                if (!this.remainingSeconds[id]) {
                    this.remainingSeconds[id] = this.parseTime(element.textContent.trim());
                }

                if (this.remainingSeconds[id] <= 0) return;

                this.activeIntervals[id] = setInterval(() => {
                    if (this.remainingSeconds[id] > 0) {
                        this.remainingSeconds[id]--;
                        element.textContent = this.formatTime(this.remainingSeconds[id]);
                    } else {
                        this.pause(id);
                        alert('Itineray alarm! Visit complete.');
                    }
                }, 1000);
            },

            pause(id) {
                clearInterval(this.activeIntervals[id]);
                delete this.activeIntervals[id];
            },

            reset(id, originalTime) {
                this.pause(id);
                this.remainingSeconds[id] = this.parseTime(originalTime);
                document.getElementById('count-' + id).textContent = this.formatTime(this.remainingSeconds[id]);
            },

            parseTime(t) {
                const parts = t.split(':');
                return (parseInt(parts[0]) || 0) * 3600 + (parseInt(parts[1]) || 0) * 60 + (parseInt(parts[2]) || 0);
            },

            formatTime(s) {
                const h = Math.floor(s / 3600).toString().padStart(2, '0');
                const m = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
                const sc = (s % 60).toString().padStart(2, '0');
                return `${h}:${m}:${sc}`;
            }
        };
    </script>
</body>

</html>
