document.getElementById('feedback-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const submitBtn = document.getElementById('submit-btn');
    const statusMsg = document.getElementById('status-message');

    submitBtn.disabled = true;
    const originalBtnText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    statusMsg.innerHTML = '';

    const formData = new FormData(this);
    const data = {
        rating: formData.get('rating'),
        message: formData.get('message')
    };

    try {
        const response = await fetch('save_feedback.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const result = await response.json();

        if (result.status === 'success') {
            statusMsg.innerHTML = '<span class="status-success"><i class="fas fa-check-circle"></i> Thank you! Your feedback has been received.</span>';
            document.getElementById('feedback-form').reset();
        } else {
            statusMsg.innerHTML = `<span class="status-error"><i class="fas fa-exclamation-circle"></i> Error: ${result.message}</span>`;
        }
    } catch (error) {
        console.error('Error submitting feedback:', error);
        statusMsg.innerHTML = '<span class="status-error"><i class="fas fa-exclamation-circle"></i> Connection error. Please try again later.</span>';
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnText;
    }
});


