<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Tourist Places</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="tourist.css">
    <script src="theme.js"></script>
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="filter-section">
            <h2>Explore Tourist Attractions</h2>
            <div class="filter-buttons">
                <button class="filter-btn active" data-category="all">All</button>
                <button class="filter-btn" data-category="beach">Beaches</button>
                <button class="filter-btn" data-category="temple">Temples</button>
                <button class="filter-btn" data-category="heritage">Heritage</button>
                <button class="filter-btn" data-category="nature">Nature</button>
            </div>
        </div>

        <section class="attractions-grid" id="attractions-grid">

        </section>
    </main>

    <script src="tourist.js"></script>
</body>

</html>



