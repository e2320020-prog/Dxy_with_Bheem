<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$username = "root";
$password = "";
$dbname = "way to home";

try {
    $conn = mysqli_connect($host, $username, $password);
    if (!$conn) {
        die("Connect failed: " . mysqli_connect_error());
    }
    echo "Connected successfully to MySQL server.\n";

    $sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
    if (mysqli_query($conn, $sql)) {
        echo "Database created/exists.\n";
        if (mysqli_select_db($conn, $dbname)) {
            echo "Selected database '$dbname'.\n";
        }
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Code: " . $e->getCode() . "\n";
}
?>
