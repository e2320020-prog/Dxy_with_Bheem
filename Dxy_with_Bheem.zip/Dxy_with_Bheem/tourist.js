let attractions = [];

async function fetchAttractions() {
    try {
        const response = await fetch('get_attractions.php');
        attractions = await response.json();
        renderAttractions();
    } catch (error) {
        console.error('Error fetching attractions:', error);
    }
}

function renderAttractions(filter = 'all') {
    const grid = document.getElementById('attractions-grid');
    if (!grid) return;
    grid.innerHTML = '';

    const filteredAttractions = filter === 'all'
        ? attractions
        : attractions.filter(attraction => attraction.category === filter);

    const visibleAttractions = filteredAttractions.slice(0, 12);

    if (visibleAttractions.length === 0) {
        grid.innerHTML = '<div class="empty-msg">No attractions found in this category.</div>';
        return;
    }

    visibleAttractions.forEach((attraction, index) => {
        const card = document.createElement('div');
        card.className = 'attraction-card';
        card.style.animationDelay = `${index * 0.1}s`;

        card.innerHTML = `
            <i class="fas ${attraction.icon || 'fa-map-marker-alt'}"></i>
            <h3>${attraction.name}</h3>
            <p>${attraction.description}</p>
            <button class="view-btn" data-id="${attraction.id}">
                <i class="fas fa-map-marked-alt"></i> View on Map
            </button>
        `;

        grid.appendChild(card);
    });

    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const attractionId = this.getAttribute('data-id');
            viewOnMap(attractionId);
        });
    });
}

function setupFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');

    filterButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            filterButtons.forEach(b => b.classList.remove('active'));

            this.classList.add('active');

            const category = this.getAttribute('data-category');
            renderAttractions(category);
        });
    });
}

function viewOnMap(attractionId) {
    const attraction = attractions.find(a => a.id == attractionId);

    if (attraction && attraction.latitude && attraction.longitude) {
        sessionStorage.setItem('selectedAttraction', JSON.stringify({
            name: attraction.name,
            coordinates: [parseFloat(attraction.latitude), parseFloat(attraction.longitude)]
        }));

        window.location.href = 'home.php';
    } else {
        alert('Location coordinates not available for this attraction.');
    }
}

window.addEventListener('load', function () {
    fetchAttractions();
    setupFilters();
});


