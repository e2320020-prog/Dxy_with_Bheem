<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback - Dxy With Bheem</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="feedback.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="feedback-container" style="padding: 40px 20px; display: flex; justify-content: center;">
            <div class="feedback-card" style="background: white; padding: 40px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.1); width: 100%; max-width: 700px;">
                <div class="back-link" style="margin-bottom: 30px;">
                    <a href="home.php" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-weight: 600; font-family: 'Segoe UI', sans-serif;">
                        <i class="fas fa-arrow-left"></i> Back to Home
                    </a>
                </div>
                <h2 style="margin: 0 0 10px 0; font-size: 32px; color: #1e293b; font-family: 'Segoe UI', sans-serif;">Your Feedback</h2>
                <p style="color: #64748b; margin-bottom: 40px; font-size: 16px;">Hi <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>, we value your thoughts! Please let us know how we can improve.</p>

                <form id="feedback-form">
                    <div class="rating-group" style="margin-bottom: 30px;">
                        <label style="display: block; margin-bottom: 15px; font-weight: 600; color: #334155;">How would you rate your experience?</label>
                        <div class="stars">
                            <input type="radio" id="star5" name="rating" value="5" required style="display: none;"><label for="star5" title="5 stars" style="cursor: pointer; font-size: 30px; color: #cbd5e1; transition: color 0.2s;"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star4" name="rating" value="4" style="display: none;"><label for="star4" title="4 stars" style="cursor: pointer; font-size: 30px; color: #cbd5e1; transition: color 0.2s;"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star3" name="rating" value="3" style="display: none;"><label for="star3" title="3 stars" style="cursor: pointer; font-size: 30px; color: #cbd5e1; transition: color 0.2s;"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star2" name="rating" value="2" style="display: none;"><label for="star2" title="2 stars" style="cursor: pointer; font-size: 30px; color: #cbd5e1; transition: color 0.2s;"><i class="fas fa-star"></i></label>
                            <input type="radio" id="star1" name="rating" value="1" style="display: none;"><label for="star1" title="1 star" style="cursor: pointer; font-size: 30px; color: #cbd5e1; transition: color 0.2s;"><i class="fas fa-star"></i></label>
                        </div>
                    </div>

                    <div class="input-group" style="margin-bottom: 30px;">
                        <label for="message" style="display: block; margin-bottom: 10px; font-weight: 600; color: #334155;">Message</label>
                        <textarea id="message" name="message" rows="5" placeholder="Share your experience..." required style="width: 100%; padding: 15px; border: 2px solid #e2e8f0; border-radius: 12px; font-family: inherit; font-size: 15px; outline: none; transition: border-color 0.3s; box-sizing: border-box;"></textarea>
                    </div>

                    <button type="submit" id="submit-btn" class="submit-btn" style="width: 100%; background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%); color: white; border: none; padding: 15px; border-radius: 12px; font-size: 16px; font-weight: 700; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <i class="fas fa-paper-plane"></i> Submit Feedback
                    </button>
                    <div id="status-message" class="status-message" style="margin-top: 20px; text-align: center; font-weight: 600;"></div>
                </form>
            </div>
        </div>
    </main>

    <script src="feedback.js"></script>
</body>

</html>
