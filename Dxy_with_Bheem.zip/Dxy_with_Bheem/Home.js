let map;
let myLocation = [6.582175, 80.146848]; // New fixed location coordinates
let routingControl;
let fixedMarker;

let attractions = [];

async function fetchAttractionsForHome() {
    try {
        const response = await fetch('get_attractions.php');
        attractions = await response.json();
    } catch (error) {
        console.error('Error fetching attractions for home:', error);
    }
}

function displaySearchSuggestions(query) {
    const searchResults = document.getElementById('search-results');
    
    if (!query || query.length < 2) {
        searchResults.classList.remove('active');
        return;
    }

    const filtered = attractions.filter(attr => 
        attr.name.toLowerCase().includes(query.toLowerCase()) ||
        attr.description.toLowerCase().includes(query.toLowerCase()) ||
        attr.category.toLowerCase().includes(query.toLowerCase())
    );

    if (filtered.length === 0) {
        searchResults.classList.remove('active');
        return;
    }

    searchResults.innerHTML = filtered.slice(0, 6).map(attr => `
        <div class="search-result-item" onclick="searchAttractionFromInput('${attr.name}', '${attr.location_link}')">
            <i class="fas fa-map-marker-alt"></i>
            <div class="search-result-text">
                <div class="search-result-name">${attr.name}</div>
                <div class="search-result-category">${attr.category}</div>
            </div>
        </div>
    `).join('');

    searchResults.classList.add('active');
}

function searchAttractionFromInput(name, locationLink) {
    document.getElementById('location-input').value = name;
    document.getElementById('search-results').classList.remove('active');
    
    if (locationLink) {
        try {
            // Assuming location_link contains coordinates in format like "6.927079,80.770007"
            const coords = locationLink.split(',').map(c => parseFloat(c.trim()));
            if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
                saveHistory('attraction', name, coords);
                showRoute(coords, name);
            } else {
                searchLocation(name);
            }
        } catch (error) {
            console.error('Error parsing location link:', error);
            searchLocation(name);
        }
    } else {
        searchLocation(name);
    }
}

function initMap() {
    map = L.map('map').setView(myLocation, 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    fixedMarker = L.marker(myLocation).addTo(map)
        .bindPopup('<strong>Main Office</strong><br>Fixed Destination')
        .openPopup();

    const searchInput = document.getElementById('location-input');
    const searchButton = document.getElementById('search-button');
    const searchResults = document.getElementById('search-results');

    searchInput.addEventListener('input', function () {
        displaySearchSuggestions(this.value);
    });

    searchButton.addEventListener('click', function () {
        const query = searchInput.value;
        if (query) {
            searchResults.classList.remove('active');
            searchLocation(query);
        }
    });

    searchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            const query = this.value;
            if (query) {
                searchResults.classList.remove('active');
                searchLocation(query);
            }
        }
    });

    document.addEventListener('click', function (e) {
        if (!e.target.closest('.sidebar-search-wrapper')) {
            searchResults.classList.remove('active');
        }
    });

    checkSelectedAttraction();
}



function checkSelectedAttraction() {
    const selectedAttraction = sessionStorage.getItem('selectedAttraction');
    if (selectedAttraction) {
        try {
            const attraction = JSON.parse(selectedAttraction);
            sessionStorage.removeItem('selectedAttraction');

            map.setView(attraction.coordinates, 15);
            const marker = L.marker(attraction.coordinates).addTo(map)
                .bindPopup(`<strong>${attraction.name}</strong><br>Selected Location`)
                .openPopup();
        } catch (error) {
            console.error('Error parsing selected attraction:', error);
        }
    }
}

document.getElementById('my-location-button').addEventListener('click', function () {
    const btn = this;
    const originalContent = btn.innerHTML;

    const proceed = confirm("To show the route from your current position, we need to access your location. Would you like to proceed?");

    if (proceed) {
        if (navigator.geolocation) {
            // Show loading state
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Getting Location...';

            navigator.geolocation.getCurrentPosition(
                function (position) {
                    const userLocation = [position.coords.latitude, position.coords.longitude];
                    showRoute(userLocation, "My Location");

                    // Reset button
                    btn.disabled = false;
                    btn.innerHTML = originalContent;
                },
                function (error) {
                    btn.disabled = false;
                    btn.innerHTML = originalContent;

                    let errorMsg = "Unable to get your location.";
                    if (error.code === error.PERMISSION_DENIED) {
                        errorMsg = "Location access denied. Please enable location permissions in your browser settings to use this feature.";
                    } else if (error.code === error.POSITION_UNAVAILABLE) {
                        errorMsg = "Location information is unavailable.";
                    } else if (error.code === error.TIMEOUT) {
                        errorMsg = "Location request timed out.";
                    }
                    alert(errorMsg);
                },
                { timeout: 10000 } // Add a timeout for better UX
            );
        } else {
            alert("Geolocation is not supported by your browser.");
        }
    }
});

window.addEventListener('load', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('search');
    const myLocationReq = urlParams.get('mylocation');

    if (searchQuery) {
        document.getElementById('location-input').value = searchQuery;
        searchLocation(searchQuery);
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (myLocationReq === 'true') {
        document.getElementById('my-location-button').click();
        window.history.replaceState({}, document.title, window.location.pathname);
    }
});


async function saveHistory(type, name, coordinates = null) {
    try {
        const body = { 
            locationName: name, 
            searchType: type 
        };
        
        if (coordinates && coordinates.length >= 2) {
            body.lat = coordinates[0];
            body.lng = coordinates[1];
        }

        await fetch('save_history.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
    } catch (error) {
        console.error('Error saving history:', error);
    }
}



function searchLocation(query) {
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`, {
        headers: {
            'User-Agent': 'DxyWithBheem/1.0'
        }
    })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            if (data && data.length > 0) {
                const result = data[0];
                const userLocation = [parseFloat(result.lat), parseFloat(result.lon)];
                saveHistory('search', query, userLocation);
                showRoute(userLocation, result.display_name || query);
            } else {
                alert("Location not found. Please try another search.");
            }
        })
        .catch(error => {
            console.error('Search error:', error);
            alert("Error searching for location. Please try again.");
        });
}

function showRoute(startCoords, startName) {
    if (routingControl) {
        map.removeControl(routingControl);
    }

    routingControl = L.Routing.control({
        waypoints: [
            L.latLng(startCoords[0], startCoords[1]),
            L.latLng(myLocation[0], myLocation[1])
        ],
        routeWhileDragging: false,
        addWaypoints: false,
        showAlternatives: true,
        lineOptions: {
            styles: [{ color: '#667eea', opacity: 0.85, weight: 8 }]
        },
        altLineOptions: {
            styles: [{ color: '#cbd5e0', opacity: 0.5, weight: 6 }]
        },
        createMarker: function (i, waypoint, n) {
            if (i === 0) {
                return L.marker(waypoint.latLng, {
                    icon: L.icon({
                        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
                        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41],
                        popupAnchor: [1, -34],
                        shadowSize: [41, 41]
                    })
                }).bindPopup(`<strong>${startName}</strong>`);
            }
            return null; 
        }
    }).addTo(map);

    const bounds = L.latLngBounds([startCoords, myLocation]);
    map.fitBounds(bounds, { padding: [80, 80] });
}

window.addEventListener('load', async function() {
    await fetchAttractionsForHome();
    initMap();
});


