<?php
session_start();
require_once 'db_connect.php';

$error = "";
$success = "";
$step = isset($_SESSION['reset_step']) ? $_SESSION['reset_step'] : 1;

if (isset($_GET['reset'])) {
    unset($_SESSION['reset_step']);
    unset($_SESSION['reset_user_id']);
    unset($_SESSION['reset_user_type']);
    unset($_SESSION['reset_otp']);
    unset($_SESSION['reset_otp_time']);
    unset($_SESSION['reset_email']);
    header("Location: forgot-password.php");
    exit();
}

function generateOTP() {
    return rand(100000, 999999);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['verify_identity'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);

        $sql = "SELECT id FROM `users` WHERE `username` = '$username' AND `email` = '$email'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['reset_user_id'] = $user['id'];
            $_SESSION['reset_user_type'] = 'user';
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_step'] = 2;
            $_SESSION['reset_otp'] = rand(100000, 999999);
            $_SESSION['reset_otp_time'] = time();
            header("Location: forgot-password.php");
            exit();
        }

        $sql = "SELECT id FROM `admin` WHERE `username` = '$username' AND `email` = '$email'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['reset_user_id'] = $user['id'];
            $_SESSION['reset_user_type'] = 'admin';
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_step'] = 2;
            $_SESSION['reset_otp'] = rand(100000, 999999);
            $_SESSION['reset_otp_time'] = time();
            header("Location: forgot-password.php");
            exit();
        }

        $error = "No matching account found with that username and email.";
    } elseif (isset($_POST['resend_otp'])) {
        // Generate new OTP and reset timer
        $_SESSION['reset_otp'] = rand(100000, 999999);
        $_SESSION['reset_otp_time'] = time();
        $success = "New OTP has been generated!";
    } elseif (isset($_POST['verify_otp'])) {
        // Check if OTP has expired (60 seconds)
        $otp_age = time() - $_SESSION['reset_otp_time'];
        if ($otp_age > 60) {
            $error = "OTP has expired. Please request a new one.";
            unset($_SESSION['reset_step']);
            unset($_SESSION['reset_user_id']);
            unset($_SESSION['reset_user_type']);
            unset($_SESSION['reset_otp']);
            unset($_SESSION['reset_otp_time']);
            unset($_SESSION['reset_email']);
        } else {
            $entered_otp = $_POST['otp'];
            if ($entered_otp == $_SESSION['reset_otp']) {
                $_SESSION['reset_step'] = 3;
                header("Location: forgot-password.php");
                exit();
            } else {
                $error = "Invalid OTP. Please try again.";
            }
        }
    } elseif (isset($_POST['reset_password'])) {
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        if ($password !== $confirm_password) {
            $error = "Passwords do not match.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $user_id = $_SESSION['reset_user_id'];
            $table = ($_SESSION['reset_user_type'] === 'admin') ? 'admin' : 'users';

            $sql = "UPDATE `$table` SET `password` = '$hashed_password' WHERE `id` = $user_id";
            if (mysqli_query($conn, $sql)) {
                // Success! Clean up and redirect
                unset($_SESSION['reset_step']);
                unset($_SESSION['reset_user_id']);
                unset($_SESSION['reset_user_type']);
                unset($_SESSION['reset_otp']);
                $success = "Password reset successfully! Redirecting to login...";
                header("refresh:2;url=login.php");
            } else {
                $error = "Error updating password: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Dxy With Bheem</title>
    <link rel="stylesheet" href="auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .otp-hint { background: rgba(255, 255, 255, 0.1); padding: 10px; border-radius: 5px; margin-bottom: 20px; text-align: center; border: 1px dashed #ffd700; }
        .step-indicator { display: flex; justify-content: space-between; margin-bottom: 30px; position: relative; }
        .step-indicator::before { content: ''; position: absolute; top: 15px; left: 0; right: 0; height: 2px; background: rgba(255, 255, 255, 0.1); z-index: 1; }
        .step { width: 30px; height: 30px; border-radius: 50%; background: #333; display: flex; items-center: center; justify-content: center; z-index: 2; font-size: 0.8em; border: 2px solid #555; }
        .step.active { background: #4285F4; border-color: #4285F4; }
        .step.completed { background: #4caf50; border-color: #4caf50; }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="back-link" style="margin-bottom: 25px; margin-top: 15px; text-align: left;">
    <a href="javascript:history.back()" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-family: 'Segoe UI', Arial, sans-serif; font-size: 15px; font-weight: 600; transition: color 0.2s ease;" onmouseover="this.style.color='#3E5262'" onmouseout="this.style.color='#5A7184'">
    <i class="fas fa-arrow-left" style="font-size: 14px;"></i> Back to Login
</a>
</div>
		<div class="brand-heading">Dxy With Bheem</div>
        <div class="auth-header">
            <i class="fas fa-key"></i>
            <h2>Reset Password</h2>
            <p>Step <?php echo $step; ?> of 3</p>
        </div>

        <div class="step-indicator">
            <div class="step <?php echo $step >= 1 ? ($step > 1 ? 'completed' : 'active') : ''; ?>">1</div>
            <div class="step <?php echo $step >= 2 ? ($step > 2 ? 'completed' : 'active') : ''; ?>">2</div>
            <div class="step <?php echo $step >= 3 ? ($step > 3 ? 'completed' : 'active') : ''; ?>">3</div>
        </div>

        <?php if ($error): ?>
            <div class="status-msg status-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="status-msg status-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if ($step == 1): ?>
            <form method="POST">
                <div class="form-group">
                    <label>Username</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" name="username" placeholder="Enter username" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" name="email" placeholder="Enter registered email" required>
                    </div>
                </div>
                <button type="submit" name="verify_identity" class="auth-btn">Verify Identity</button>
            </form>

        <?php elseif ($step == 2): ?>
            <div class="otp-hint">
                <p><i class="fas fa-key"></i> <strong>Your One-Time Password (OTP):</strong></p>
                <h1 style="color: #ff4b2b; font-size: 48px; letter-spacing: 8px; margin: 20px 0; font-weight: bold;">
                    <?php echo $_SESSION['reset_otp']; ?>
                </h1>
                <p style="font-size: 0.9em; margin-top: 10px; color: rgba(255,255,255,0.8);">
                    <i class="fas fa-hourglass-end"></i> OTP expires in <span id="timer" style="color: #ff4b2b; font-weight: bold;">60</span> seconds
                </p>
            </div>
            <form method="POST" id="otpForm">
                <div class="form-group">
                    <label>Enter 6-Digit OTP</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="number" name="otp" placeholder="000000" required maxlength="6">
                    </div>
                </div>
                <button type="submit" name="verify_otp" class="auth-btn">Verify OTP</button>
            </form>
            <form method="POST" style="margin-top: 15px;">
                <button type="submit" name="resend_otp" class="auth-btn" id="resendBtn" style="background: #FFA500; opacity: 0.5; cursor: not-allowed;" disabled>
                    <i class="fas fa-refresh"></i> Generate New OTP (<span id="resendTimer">60</span>s)
                </button>
            </form>
            <p style="text-align: center; margin-top: 15px;"><a href="?reset=1" style="color: #ea4335;">Cancel and Restart</a></p>
            <script>
                const otpTime = <?php echo $_SESSION['reset_otp_time']; ?>;
                
                function updateTimers() {
                    const elapsed = Math.floor(Date.now() / 1000) - otpTime;
                    const remaining = 60 - elapsed;
                    
                    if (remaining > 0) {
                        document.getElementById('timer').textContent = remaining;
                        document.getElementById('resendTimer').textContent = remaining;
                        document.getElementById('resendBtn').style.opacity = '0.5';
                        document.getElementById('resendBtn').disabled = true;
                        setTimeout(updateTimers, 1000);
                    } else {
                        document.getElementById('timer').textContent = '0';
                        document.getElementById('resendBtn').style.opacity = '1';
                        document.getElementById('resendBtn').disabled = false;
                        document.getElementById('resendBtn').style.cursor = 'pointer';
                    }
                }
                
                updateTimers();
            </script>

        <?php elseif ($step == 3): ?>
            <form method="POST">
                <div class="form-group">
                    <label>New Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" name="password" id="reset_password" placeholder="Min 6 characters" required minlength="6">
                        <i class="fas fa-eye toggle-password" onclick="togglePassword('reset_password')"></i>
                    </div>
                </div>
                <div class="form-group">
                    <label>Confirm Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-check-double input-icon"></i>
                        <input type="password" name="confirm_password" id="reset_confirm_password" placeholder="Repeat password" required minlength="6">
                        <i class="fas fa-eye toggle-password" onclick="togglePassword('reset_confirm_password')"></i>
                    </div>
                </div>
                <button type="submit" name="reset_password" class="auth-btn">Update Password</button>
            </form>
        <?php endif; ?>

        <div class="auth-footer">
            Remember your password? <a href="login.php">Log In</a>
        </div>
    </div>

    <script>
        function togglePassword(id) {
            const el = document.getElementById(id);
            const icon = el.nextElementSibling;
            if (el.type === "password") {
                el.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                el.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>
</html>


