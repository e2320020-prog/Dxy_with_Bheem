
document.addEventListener('DOMContentLoaded', function () {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.left-dropdown a, .dropdown a, .side-bar-left a');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && (currentPath.endsWith(href) || (href === 'home.php' && currentPath.endsWith('/')))) {
            link.classList.add('active');
        }
    });

    const locationInput = document.getElementById('location-input');
    const searchButton = document.getElementById('search-button');

    function handleSearch(query) {
        if (!query || query.trim() === "") return;

        if (typeof window.searchLocation === 'function') {
            window.searchLocation(query);
        } else {
            window.location.href = `home.php?search=${encodeURIComponent(query.trim())}`;
        }
    }

    if (locationInput) {
        locationInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                handleSearch(this.value);
            }
        });
    }

    if (searchButton) {
        searchButton.addEventListener('click', function () {
            handleSearch(locationInput.value);
        });
    }

    const myLocationBtn = document.getElementById('my-location-button');
    if (myLocationBtn) {
        myLocationBtn.addEventListener('click', function () {
            if (typeof window.showRoute === 'function') {
            } else {
                window.location.href = 'home.php?mylocation=true';
            }
        });
    }

    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('search');
    const myLocationTrigger = urlParams.get('mylocation');

    if (searchQuery && locationInput && !window.location.pathname.includes('home.php')) {
        locationInput.value = searchQuery;
    }
});

window.hideSearchResults = function() {
    const results = document.getElementById('search-results');
    if (results) results.style.display = 'none';
};

window.showHistoryDropdown = function(mode) {
    // This can be expanded if we want a live history dropdown in the sidebar
    console.log("Showing history mode: " + mode);
};
