<Doctype html>
    <html>

    <head>
        <title>Way to Home</title>
        <link rel="stylesheet" href="login.css">
    </head>

    <body>
        <h1>Dxy With Bheem</h1>
        <div class="box">
        </div>
        <div>
            <a href="login.php">
                <button class="button">Lets go Folks &nbsp; &#10132;</button>
            </a>
        </div>
    </body>

    </html>
