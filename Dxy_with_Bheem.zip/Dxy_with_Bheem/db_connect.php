<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "way to home";

try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    
    $conn = mysqli_connect("127.0.0.1", $username, $password);

    $sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
    mysqli_query($conn, $sql);
    
    mysqli_select_db($conn, $dbname);

} catch (mysqli_sql_exception $e) {
    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || 
              (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) ||
              (basename($_SERVER['PHP_SELF']) == 'save_history.php') ||
              (basename($_SERVER['PHP_SELF']) == 'get_attractions.php');

    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Database Error: ' . $e->getMessage()]);
    } else {
        echo "<div style='padding: 20px; background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; border-radius: 8px; font-family: sans-serif; margin: 20px;'>";
        echo "<strong>Database Connection Error:</strong><br>";
        echo "Please ensure that your MySQL server is running in the XAMPP Control Panel.<br>";
        echo "<small style='color: #ef4444;'>Details: " . $e->getMessage() . "</small>";
        echo "</div>";
    }
    exit();
}
?>

