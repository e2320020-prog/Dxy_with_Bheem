<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$placesResult = mysqli_query($conn, "SELECT id, name, category, icon FROM tourist_places ORDER BY name");
$places = [];
while ($place = mysqli_fetch_assoc($placesResult)) {
    $places[] = $place;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $schedule_name = mysqli_real_escape_string($conn, $_POST['schedule_name']);
    $starting_time = mysqli_real_escape_string($conn, $_POST['starting_time']);
    $finishing_time = mysqli_real_escape_string($conn, $_POST['finishing_time']);

    $place_values = [];
    $time_values = [];
    for ($i = 1; $i <= 10; $i++) {
        $place_values[] = (isset($_POST["place_$i"]) && $_POST["place_$i"] !== '') ? (int)$_POST["place_$i"] : 'NULL';
        $time_values[] = (isset($_POST["time_$i"]) && $_POST["time_$i"] !== '') ? "'".mysqli_real_escape_string($conn, $_POST["time_$i"])."'" : 'NULL';
    }

    $values_str = implode(',', $place_values);
    $time_str = implode(',', $time_values);

    $sql = "INSERT INTO schedules (user_id, username, user_role, schedule_name, place_1, place_2, place_3, place_4, place_5, place_6, place_7, place_8, place_9, place_10, time_1, time_2, time_3, time_4, time_5, time_6, time_7, time_8, time_9, time_10, starting_time, finishing_time) 
            VALUES ({$_SESSION['user_id']}, '{$_SESSION['username']}', '{$_SESSION['role']}', '$schedule_name', $values_str, $time_str, '$starting_time', '$finishing_time')";

    if (mysqli_query($conn, $sql)) {
        $success_msg = "Schedule saved successfully!";
    } else {
        $error_msg = "Error saving schedule: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Schedule - Dxy With Bheem</title>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .schedule-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .schedule-card {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }

        .schedule-title {
            font-size: 32px;
            color: #1e293b;
            margin-bottom: 30px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 700;
            color: #334155;
            font-size: 14px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 14px;
            background: #f8fafc;
            border: 2px solid #f1f5f9;
            border-radius: 12px;
            color: #1e293b;
            font-family: inherit;
            font-size: 15px;
            transition: all 0.3s;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #00C6FF;
            background: white;
            box-shadow: 0 0 0 4px rgba(0, 198, 255, 0.08);
        }

        .place-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 30px;
            padding: 25px;
            background: #f8fafc;
            border-radius: 15px;
            border: 1px solid #e2e8f0;
        }

        .place-dropdown {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .place-label {
            background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            width: fit-content;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 40px;
            justify-content: center;
        }

        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #00C6FF 0%, #0072FF 100%);
            color: white;
            flex: 1;
            justify-content: center;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 114, 255, 0.3);
        }

        .btn-reset {
            background: #f1f5f9;
            color: #64748b;
        }

        .btn-reset:hover {
            background: #e2e8f0;
        }

        .alert {
            padding: 15px 20px;
            margin-bottom: 30px;
            border-radius: 12px;
            text-align: center;
            font-weight: 700;
        }

        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .alert-error {
            background: #fff1f2;
            color: #e11d48;
            border: 1px solid #fecdd3;
        }
    </style>
</head>

<body>
    <header>
        <div class="header">
            <div class="logo-container">
                <i class="fas fa-route logo-icon"></i>
                <div class="logo-text">
                    <h1 class="title">Dxy With Bheem</h1>
                    <p class="subtitle">Your Smart Travel Companion</p>
                </div>
            </div>
            <div class="user-info" style="position: absolute; right: 80px; top: 20px; color: white; display: flex; align-items: center; gap: 20px;">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="logout.php" style="color: #ff4b2b; text-decoration: none;"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="main-content">
        <div class="schedule-container">
            <div class="schedule-card">
                <div class="back-link" style="margin-bottom: 30px;">
                    <a href="home.php" style="display: inline-flex; align-items: center; gap: 8px; color: #5A7184; text-decoration: none; font-weight: 600;">
                        <i class="fas fa-arrow-left"></i> Back to Home
                    </a>
                </div>

                <h1 class="schedule-title"><i class="fas fa-magic" style="color: #0072FF;"></i> Schedule Generator</h1>

                <?php if (isset($success_msg)): ?>
                    <div class="alert alert-success"><?php echo $success_msg; ?></div>
                <?php endif; ?>

                <?php if (isset($error_msg)): ?>
                    <div class="alert alert-error"><?php echo $error_msg; ?></div>
                <?php endif; ?>

                <form method="POST">
                    <input type="hidden" name="action" value="save">

                    <div class="form-group">
                        <label><i class="fas fa-heading"></i> Schedule Name</label>
                        <input type="text" name="schedule_name" placeholder="e.g., Weekend Beach Tour" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-clock"></i> Starting Time</label>
                            <input type="time" name="starting_time" required>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-stop-circle"></i> Finishing Time</label>
                            <input type="time" name="finishing_time" required>
                        </div>
                    </div>

                    <p style="text-align: center; color: #64748b; margin: 30px 0 20px; font-size: 14px; font-weight: 600;">
                        <i class="fas fa-info-circle"></i> Select tourist places and set the allocated visitation time.
                    </p>

                    <?php for ($i = 1; $i <= 10; $i += 2): ?>
                        <div class="place-row">
                            <div class="place-dropdown">
                                <span class="place-label">#<?php echo $i; ?></span>
                                <select name="place_<?php echo $i; ?>">
                                    <option value="">-- Select Destination --</option>
                                    <?php foreach ($places as $place): ?>
                                        <option value="<?php echo $place['id']; ?>">
                                            <?php echo htmlspecialchars($place['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="time" name="time_<?php echo $i; ?>" step="1">
                            </div>

                            <?php if ($i < 10): ?>
                                <div class="place-dropdown">
                                    <span class="place-label">#<?php echo $i + 1; ?></span>
                                    <select name="place_<?php echo $i + 1; ?>">
                                        <option value="">-- Select Destination --</option>
                                        <?php foreach ($places as $place): ?>
                                            <option value="<?php echo $place['id']; ?>">
                                                <?php echo htmlspecialchars($place['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="time" name="time_<?php echo $i + 1; ?>" step="1">
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endfor; ?>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-submit"><i class="fas fa-save"></i> Save My Schedule</button>
                        <button type="reset" class="btn btn-reset">Reset</button>
                    </div>
                </form>
            </div>
        </div>
    </main>

</body>

</html>
